package com.tory.tory.mixin;

import com.tory.tory.client.ToryClient;
import net.minecraft.class_1713;
import net.minecraft.class_310;
import net.minecraft.class_312;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_312.class)
public class MouseMixin {

	private static long lastScrollTime = 0;

	@Inject(method = "onMouseScroll", at = @At("HEAD"), cancellable = true)
	private void onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
		if (!ToryClient.isToryActive) return;

		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || client.field_1755 != null || client.field_1761 == null) return;

		// Debounce
		long now = System.currentTimeMillis();
		if (now - lastScrollTime < 140) return;
		lastScrollTime = now;

		if (Math.abs(vertical) < 0.15) return;

		// Completely cancel vanilla scroll
		ci.cancel();

		// Always use the locked column
		int selected = ToryClient.lockedSlot;
		client.field_1724.method_31548().field_7545 = selected;

		int hotbarSlot = 36 + selected;
		int row1 = 27 + selected;
		int row2 = 18 + selected;
		int row3 = 9 + selected;

		if (vertical > 0) {
			// Scroll up
			swapSlots(client, hotbarSlot, row1);
			swapSlots(client, row1, row2);
			swapSlots(client, row2, row3);
		} else {
			// Scroll down
			swapSlots(client, hotbarSlot, row3);
			swapSlots(client, row3, row2);
			swapSlots(client, row2, row1);
		}

		// Force lock again
		client.field_1724.method_31548().field_7545 = selected;
	}

	private void swapSlots(class_310 client, int slotA, int slotB) {
		client.field_1761.method_2906(
			client.field_1724.field_7498.field_7763,
			slotA, 0, class_1713.field_7790, client.field_1724);
		client.field_1761.method_2906(
			client.field_1724.field_7498.field_7763,
			slotB, 0, class_1713.field_7790, client.field_1724);
		client.field_1761.method_2906(
			client.field_1724.field_7498.field_7763,
			slotA, 0, class_1713.field_7790, client.field_1724);
	}
}
