package com.tory.tory;

import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.qsl.base.api.entrypoint.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ToryMod implements ModInitializer {
	public static final String MOD_ID = "tory";
	public static final Logger LOGGER = LoggerFactory.getLogger("Tory");

	@Override
	public void onInitialize(ModContainer mod) {
		LOGGER.info("Tory mod initialized!");
	}
}
