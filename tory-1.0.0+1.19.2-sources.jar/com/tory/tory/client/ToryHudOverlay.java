package com.tory.tory.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_918;

public class ToryHudOverlay implements HudRenderCallback {
	private static final class_2960 WIDGETS = new class_2960("textures/gui/widgets.png");

	@Override
	public void onHudRender(class_4587 matrices, float delta) {
		if (!ToryClient.isToryActive) return;

		class_310 client = class_310.method_1551();
		if (client.field_1724 == null || client.field_1690.field_1842) return;

		class_1661 inv = client.field_1724.method_31548();
		int sw = client.method_22683().method_4486();
		int sh = client.method_22683().method_4502();

		int x = sw / 2 - 91;
		int y = sh - 22 - 66;

		RenderSystem.setShaderTexture(0, WIDGETS);
		RenderSystem.enableBlend();
		RenderSystem.defaultBlendFunc();

		// Only draw the background once
		for (int row = 0; row < 3; row++) {
			class_332.method_25290(matrices, x, y + row * 22, 0, 0, 182, 22, 256, 256);
		}

		// Draw items only
		class_918 ir = client.method_1480();
		for (int row = 0; row < 3; row++) {
			for (int col = 0; col < 9; col++) {
				class_1799 stack = inv.method_5438(9 + row * 9 + col);
				if (!stack.method_7960()) {
					int ix = x + col * 20 + 3;
					int iy = y + row * 22 + 3;
					ir.method_4023(stack, ix, iy);
					ir.method_4025(client.field_1772, stack, ix, iy);
				}
			}
		}

		RenderSystem.disableBlend();
	}
}
