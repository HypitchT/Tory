package com.tory.tory.client;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import org.lwjgl.glfw.GLFW;
import org.quiltmc.loader.api.ModContainer;
import org.quiltmc.qsl.base.api.entrypoint.client.ClientModInitializer;

public class ToryClient implements ClientModInitializer {

	public static boolean isToryActive = false;
	public static int lockedSlot = 0; // the column that stays locked while Alt is held

	@Override
	public void onInitializeClient(ModContainer mod) {
		// Register the HUD
		HudRenderCallback.EVENT.register(new ToryHudOverlay());

		// Tick event – keeps the selected slot locked while Alt is held
		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			if (client.field_1724 == null) return;

			long window = client.method_22683().method_4490();
			boolean altDown = GLFW.glfwGetKey(window, GLFW.GLFW_KEY_LEFT_ALT) == GLFW.GLFW_PRESS
				|| GLFW.glfwGetKey(window, GLFW.GLFW_KEY_RIGHT_ALT) == GLFW.GLFW_PRESS;

			if (altDown && !isToryActive) {
				// Just pressed Alt → lock the current column
				lockedSlot = client.field_1724.method_31548().field_7545;
			}

			isToryActive = altDown;

			if (isToryActive) {
				// Force the selected slot to stay locked
				client.field_1724.method_31548().field_7545 = lockedSlot;
			}
		});
	}
}
